
folders = [1,2,5,11,12,16,19,22,23,27,28,33,35,39,40];
nfolders = length(folders);
A(1:1,1:4096) = 0;

for i=1:nfolders 
    DirectoryName = strcat('../data_assign1_group22/EigenAnalysis_Data/Datasets1/64x64/',int2str(folders(i)));
    imagefiles = dir(DirectoryName);
    nfiles = length(imagefiles);

    for i=1:nfiles
       currentfilename = imagefiles(i).name;
       if currentfilename(1) == '.' % do nothing
                continue;
       end
       disp(currentfilename);
       addpath '../data_assign1_group22/EigenAnalysis_Data/Datasets1/64x64/1'
       currentimage = imread(currentfilename);
       ImgVector = reshape(currentimage', 1, []);
       A = [A;ImgVector];
    end
end

A(1, :) = [];
A = double(A); 
normA = A - mean(A);

C = cov(double(normA));
[V,D] = eig(C);

Choice = [22,12,58,100,124];

i = Choice(1)

for e = [1000]
    M = V(:,[1:e]);
    p = A(i,:);
    x = p*M*transpose(M);
    I = vec2mat(x,64);
    imwrite(mat2gray(I),strcat('image',num2str(i),'-',int2str(e),'.png') );
end









