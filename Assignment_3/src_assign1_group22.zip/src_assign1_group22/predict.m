
function Y = predict(W, Phi, D)

DM_i = @(fnIdx) arrayfun(@(idx) Phi{fnIdx}(D(idx,:)), (1:size(D, 1)));

DesignMatrix = [];
for i = 1:size(Phi, 2)
    DesignMatrix = [DesignMatrix; DM_i(i)];
end
DesignMatrix = transpose(DesignMatrix);


Y = DesignMatrix * W;