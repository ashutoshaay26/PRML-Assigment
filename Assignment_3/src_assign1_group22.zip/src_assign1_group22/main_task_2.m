

model1();
findBestModel1();


function [] = model1()
    sz = 300;
    M = 7;
    lambda = 0.0;
    datasetID = 2;
    [Train, Val, Test] = loadDS(datasetID, sz);
    [W, Phi, error] = makeModel("polynomial", lambda, M, Train, Train, "quadratic");

    % plot -- uncomment to display plot
    % annot = sprintf("M = %d, Lambda = %f, Training Set Size = %d", M, lambda, size(Train, 1));
    % plot2D(W, Phi, Train, annot);

    % scatter plot
    x = transpose(Test(:,2));
    y = transpose(predict(W, Phi, Test(:,1)))
    plot(x, y, "ro")
    xlabel('Target Output t')
    ylabel('Model Output y')

    error
end


function [sz, M, lambda, error] = findBestModel1()

    hpSet = [200 5 0.1; 200 7 0.1; 200 10 0.1; 200 15 0.1; 200 20 0.1; 200 25 0.1; 200 30 0.1; 200 35 0.0];

    errors = zeros(1, size(hpSet, 1));
    for i = 1:size(hpSet, 1)
        [Train, Val, Test] = loadDS(2, hpSet(i, 1));
        [~, ~, error] = makeModel("polynomial", hpSet(i, 3), hpSet(i, 2), Train, Test, "quadratic");
        errors(i) = error;
    end
    errors
    [minerr, i] = min(errors);
    sz = hpSet(i, 1);
    M = hpSet(i, 2);
    lambda = hpSet(i, 3);
    error = minerr;

end

