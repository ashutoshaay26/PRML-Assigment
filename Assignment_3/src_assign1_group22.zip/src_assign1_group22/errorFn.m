
function e = errorFn(Y, T)

% assert the dimensions

e = norm(Y - T) / sqrt(size(Y, 1));

end

