function [] = plot2D(W, Phi, D, annot)

    %Plot curve
    x = linspace(0, 1,100);
    y = transpose(predict(W, Phi, transpose(x)));
    plot(x,y)
    hold on
    % plot the training data
    x = transpose(D(:, 1));
    t = transpose(D(:, 2));
    plot(x, t, "ro")
    xlabel('x')
    ylabel('y/t')
        
    dim = [.2 .5 .3 .3];
    annotation('textbox',dim,'String', annot,'FitBoxToText','on');
    
end