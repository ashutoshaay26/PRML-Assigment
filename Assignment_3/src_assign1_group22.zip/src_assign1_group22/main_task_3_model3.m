


% a model is represented by:
% W, Phi, lambda, M, sz

% [sz, M, lambda, error] = findBestModel1()
model3();


function [] = model3()
    sz = 721;
    M = 100;
    lambda = 0.1;
    datasetID = 3;
    [Train, Val, Test] = loadDS(datasetID, sz);
    [W, Phi, error] = makeModel("gaussb", lambda, M, Train, Test, "quadratic");

    % plot
    % annot = sprintf("M = %d, Lambda = %f, Training Set Size = %d", M, lambda, size(Train, 1));
    % plot3D(W, Phi, Val, annot);


    x = transpose(Train(:,3));
    y = transpose(predict(W, Phi, Train(:,1:2)))
    plot(x, y, "ro")
    xlabel('Target Output t')
    ylabel('Model Output y')

    error
end



function [sz, M, lambda, error] = findBestModel3()

    hpSet = [20 7 0.1; 100 7 0.1; 1000 7 0.1; 2000 10 0.1; 2000 7 1.0; 2000 20 0.1;];

    errors = zeros(1, size(hpSet, 1));
    for i = 1:size(hpSet, 1)
        [Train, Val, Test] = loadDS(3, hpSet(i, 1));
        [~, ~, error] = makeModel("gaussb", hpSet(i, 3), hpSet(i, 2), Train, Val, "quadratic");
        [W, Phi, error] = makeModel("gaussb", lambda, M, Train, Test, "quadratic");
        errors(i) = error;
    end
    errors
    [minerr, i] = min(errors);
    sz = hpSet(i, 1);
    M = hpSet(i, 2);
    lambda = hpSet(i, 3);
    error = minerr;

end





