function [] = plot3D(W, Phi, D, annot)

    max_x1 = max(D(:,1));
    max_x2 = max(D(:,2));
    min_x1 = min(D(:,1));
    min_x2 = min(D(:,2));
    x1 = min_x1:.1:max_x1;
    x2 = min_x2:.1:max_x2;
    [X, Y] = meshgrid(x1, x2);
    N = size(X, 1) * size(X, 2);
    linX = reshape(X, N, 1);
    linY = reshape(Y, N, 1);
    z = transpose(predict(W, Phi, horzcat(linX, linY)));
    Z = reshape(z, size(X, 1), size(X, 2));
    surf(X, Y, Z);
    hold on;
    
    scatter3(D(:,1), D(:,2), D(:,3));

    dim = [.2 .5 .3 .3];
    annotation('textbox', dim ,'String', annot,'FitBoxToText','on');

end
