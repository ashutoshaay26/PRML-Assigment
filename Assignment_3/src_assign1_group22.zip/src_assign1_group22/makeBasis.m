function Phi = makeBasis(kind, nvars, X, M)
    if kind == "polynomial"
        Phi = makePolyPhi(nvars, X, M);
    elseif kind == "polyb"
        Phi = makePolyBasisPhi(nvars, X, M);
    elseif kind == "gaussb"
        Phi = makeGaussianPhi(nvars, X, M);
    end
end


function Phi = makePolyPhi(nvars, X, M)
    Phi = {@(x) 1};
    for i = 2:M
        Phi{i} = @(x) x(1)^(i-1);
    end
end


function Phi = makePolyBasisPhi(nvars, X, M)
    n = nvars;
    k = 1;
    mask = zeros(1, n);
    while size(mask, 1) < M
        comb = bsxfun(@minus, nchoosek(1:n+k-1,k), 0:k-1);
        row_i = @(i) arrayfun(@(j) sum(comb(i,:) == j), 1:n);
        c = 1;
        while size(mask, 1) < M && c <= size(comb, 1)
            row_i(c)
            mask = [mask; row_i(c)];
            c = c + 1;
        end
        k = k + 1;
    end
    Phi = {};
    for i = 1:M
        Phi{i} = @(x) prod(x .^ mask(i,:));
    end
end


function Phi = makeGaussianPhi(nvars, X, M)
    [idx, C] = kmeans(X, M-1);
    Phi = {};
    Phi{1} = @(x) 1;
    for i = 2:M
        Phi{i} = @(x) exp(-norm(x-C(i-1,:))/30);
    end
end

