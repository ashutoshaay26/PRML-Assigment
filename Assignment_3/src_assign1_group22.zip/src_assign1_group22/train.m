function W = train(D, t, Phi, lambda)
% D: N x F training data
% t: N x 1 outputs
% Phi: 1 x M basis function
% lambda: Regularization coefficient
%

% Given Phi (1 x M) and D (N x F), it calculates the design matrix (N x M)
DM_i = @(fnIdx) arrayfun(@(idx) Phi{fnIdx}(D(idx,:)), (1:size(D, 1)));

DesignMatrix = [];
for i = 1:size(Phi, 2)
    DesignMatrix = [DesignMatrix; DM_i(i)];
end
DesignMatrix = transpose(DesignMatrix);

M = size(Phi, 2);

W = inv((lambda * eye(M)) + (transpose(DesignMatrix) * DesignMatrix)) * transpose(DesignMatrix) * t;
