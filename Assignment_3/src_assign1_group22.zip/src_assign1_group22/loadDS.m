function [Train, Test, Val] = loadDS(datasetID, sz)
    if datasetID == 2
        [Train, Val, Test] = loadDS2(sz);
    elseif datasetID == 3
        [Train, Val, Test] = loadDS3(sz);
    elseif datasetID == 4
        [Train, Val, Test] = loadDS4(sz);
    end
end

function [Train, Val, Test] = loadDS4(sz)
    path = '../data_assign1_group22/Concrete_Compressive_Strength_Dataset/concrete-data.txt';
    data = importdata(path);
    % shuffle
    data = data(randperm(size(data,1)),:);
    N = size(data, 1);
    Train = data(1:0.7*N,:);
    Val = data(0.7*N+1:0.9*N,:);
    Test = data(0.9*N+1:N,:);
end

function [Train, Val, Test] = loadDS3(sz)
    baseDS2Path = '../data_assign1_group22/bivariate_group22/bivariateData';
    if sz ==  20
        Train = importdata(strcat(baseDS2Path, '/train20.txt'));
    elseif sz == 100
        Train = importdata(strcat(baseDS2Path, '/train100.txt'));
    elseif sz == 1000
        Train = importdata(strcat(baseDS2Path, '/train1000.txt'));
    elseif sz == 2000
        Train = importdata(strcat(baseDS2Path, '/train.txt'));
    end
    Val = importdata(strcat(baseDS2Path, '/val.txt'));
    Test = importdata(strcat(baseDS2Path, '/test.txt'));

end

function [Train, Val, Test] = loadDS2(sz)

    assert(mod(sz, 10) == 0);

    N = sz;
    x = rand(1, N);
    y = arrayfun(@(x) exp(cos(2*pi*x)), x);
    noise = normrnd(0, 0.1, [1, N]);
    t = y + noise;
    D = transpose([x; t]);

    Train = D(1:0.7*N,:);
    Val = D(0.7*N+1:0.9*N,:);
    Test = D(0.9*N+1:N,:);

    %{
    x = rand(1, N*0.1);
    y = arrayfun(@(x) exp(cos(2*pi*x)), x);
    Test = transpose([x; y]);
    %}

end
