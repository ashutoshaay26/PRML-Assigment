

function [W, Phi, error] = makeModel(basis, lambda, M, Train, Val, regularizer)

    % number of features
    nbf = size(Train, 2) - 1;

    D = Train(:,1:nbf);
    t = Train(:,nbf+1);

    if basis == 'gaussb' && regularizer == 'tiko'
        [idx, C] = kmeans(D, M-1);
        deno = 30;
        Phi = {};
        Phi{1} = @(x) 1;
        for i = 2:M
            Phi{i} = @(x) exp(-norm(x-C(i-1,:))/deno);
        end
        DM_i = @(fnIdx) arrayfun(@(idx) Phi{fnIdx}(D(idx,:)), (1:size(D, 1)));
        DesignMatrix = [];
        for i = 1:size(Phi, 2)
            DesignMatrix = [DesignMatrix; DM_i(i)];
        end
        DesignMatrix = transpose(DesignMatrix);

        tiko_i = @(i) arrayfun(@(j) exp(-norm(C(i,:)-C(j))/deno), 1:M-1);
        tiko = [];
        for i = 1:M-1
            tiko = [tiko; tiko_i(i)];
        end
        tiko = [zeros(1, M-1); tiko];
        tiko = horzcat(zeros(M, 1), tiko);
        tiko
        W = inv((lambda * tiko) + (transpose(DesignMatrix) * DesignMatrix)) * transpose(DesignMatrix) * t;
    else
        t
        Phi = makeBasis(basis, nbf, D, M);
        W = train(D, t, Phi, lambda);
    end

    % Do prediction on Val
    V = Val(:,1:nbf);
    L = Val(:,nbf+1);
    Y = predict(W, Phi, V);
    R = horzcat(L, Y);
    error = errorFn(Y, L);

end

